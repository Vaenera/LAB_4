package Model.Vehicle;

public interface ITruckBed {
    void truckBedUp();
    void truckBedDown();
}
