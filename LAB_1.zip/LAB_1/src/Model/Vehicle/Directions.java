package Model.Vehicle;

public enum Directions {
    EAST,
    WEST,
    NORTH,
    SOUTH
}
