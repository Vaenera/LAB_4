package Model.Vehicle;

public interface ITurbo {

    void setTurboOn();

    void setTurboOff();
}
