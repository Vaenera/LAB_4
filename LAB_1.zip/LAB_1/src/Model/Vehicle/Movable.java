package Model.Vehicle;

public interface Movable {
    void move();

    void turnLeft();

    void turnRight();
}
